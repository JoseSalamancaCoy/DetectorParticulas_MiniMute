R1=50;
R2=1000;
C=22e-12;
num=R2/(R1*R2*C);
den=[1 (R1+R2)/(R1*R2*C)];
G=tf(num,den);
t=0:1e-9:100e-9;
[y,t1]=step(G,t);
plot(t,y,t,t)
figure 
w=logspace(1,10,100);
bode(G,w)