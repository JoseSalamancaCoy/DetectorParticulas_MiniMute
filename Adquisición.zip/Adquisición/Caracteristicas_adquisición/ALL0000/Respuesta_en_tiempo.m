data= dlmread('F0000CH1.CSV', ',', 500, 1);
time=data(:,3);
voltaje=data(:,4);
plot(time,voltaje,'-', 'linewidth',1.5,'Color','R')
Hs=tf([909e6],[1 4.5454e6]);

hold on
%des_filtr=lsim(Hs,voltaje,time);
%plot(time,des_filtr,'-', 'linewidth',1.5,'Color','B')

hold off
figure
bode(Hs)