data= dlmread('F0000CH1.CSV', ',', 500, 1);
time=data(:,3); 
voltaje=data(:,4);
Voltaje=[voltaje;0.5*voltaje;0.8*voltaje;2*voltaje;0.1*voltaje];
Voltaje2=[voltaje;voltaje;voltaje;voltaje;voltaje];
subplot(2,1,1);
plot(150+(time*10e8),voltaje,'-', 'linewidth',1.5,'Color','R') 
grid on 
title('Salida circuito de acondicionamiento con Rf=4.7k')
xlabel('Tiempo_{nS}','FontSize',11,'Color','k')
ylabel('Voltaje [V]','FontSize',11,'Color','k') 
legend('Pulso acondicionado','Location','southeast')

Fs= 1/(time(1000,1)-time(999,1));                         %frecuencia de muestreo
T = 1/Fs;                        % Sampling period       
L = length(Voltaje);             % Length of signal
f = Fs*(0:(L/2))/L;              %vector frecuencia para grafica FFT
t=(0:1:length(Voltaje)-1)*T;     %vectot tiempo para se�ales repetidas

%FFT y correccion de datos para se�al con amplitud igual
FFT_senal = fft((Voltaje2)/L);
P2_2 = abs(FFT_senal);
P1_2 = P2_2(1:L/2+1);
P1_2(2:end-1) = 2*P1_2(2:end-1);
f = Fs*(0:(L/2))/L;

%FFT Impresion escala logaritmica
subplot(2,1,2);
semilogx(f,P1_2)
hold off
title('Espectro del pulso')
xlabel('f_{Hz}')
ylabel('|G(f)|')
legend('Amplitud espectral','Location','southeast')

t=[0:1:10000-1]*2e-10*10e8;
figure
plot(t,Voltaje2)
xlabel('Tiempo_{nS}','FontSize',11,'Color','k')
ylabel('Voltaje [V]','FontSize',11,'Color','k') 
legend('Pulsos como serie','Location','southeast')
