Fc=0.5
num=2*pi*Fc;
den=[1 num];
H=tf(num,den);
bode(H)
Hd=c2d(H,0.2)
