

data= ('F0000CH1.CSV', ',', 500, 1);
time=data(:,3); 
voltaje=data(:,4);
Voltaje=[voltaje;0.5*voltaje;0.8*voltaje;2*voltaje;0.1*voltaje];
Voltaje2=[voltaje;voltaje;voltaje;voltaje;voltaje];

subplot(2,1,1);
plot(time,voltaje,'-', 'linewidth',1.5,'Color','R') 
grid on 
title('X(t) para Rf=470')
xlabel('Tiempo_{S}','FontSize',11,'Color','k')
ylabel('Voltaje [V]','FontSize',11,'Color','k') 
legend('Pulso acondicionado','Location','southeast')



%realizar la FFT
Fs= 5e9;                         %frecuencia de muestreo
T = 1/Fs;                        % Sampling period       
L = length(Voltaje);             % Length of signal
f = Fs*(0:(L/2))/L;              %vector frecuencia para grafica FFT
t=(0:1:length(Voltaje)-1)*T;     %vectot tiempo para se�ales repetidas

%Se�ales repetidas

%FFT y correccion de datos para se�al con distintas amplitudes
FFT_senal = fft((Voltaje)/L);
P2_1 = abs(FFT_senal);
P1_1 = P2_1(1:L/2+1);
P1_1(2:end-1) = 2*P1_1(2:end-1);


%FFT y correccion de datos para se�al con amplitud igual
FFT_senal = fft((Voltaje2)/L);
P2_2 = abs(FFT_senal);
P1_2 = P2_2(1:L/2+1);
P1_2(2:end-1) = 2*P1_2(2:end-1);
f = Fs*(0:(L/2))/L;

%FFT Impresion escala logaritmica

%%semilogx(f,P1_1)
%hold on
subplot(2,1,2);
semilogx(f,P1_2)
hold off
title('Amplitude Spectrum of X(t)')
xlabel('f (Hz)')
ylabel('|P1(f)|')

figure
plot(t,Voltaje)
hold on
plot(t,Voltaje2)
hold off
xlabel('Tiempo_{nS}','FontSize',11,'FontWeight','bold','Color','k')
ylabel('Voltaje [V]','FontSize',11,'FontWeight','bold','Color','k') 
legend('Voltaje1','Voltaje2','Location','northeast')

