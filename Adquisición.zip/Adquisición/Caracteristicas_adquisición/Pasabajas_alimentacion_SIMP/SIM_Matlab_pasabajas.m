R=1000;
C=100e-9;
RC=R*C;
num=1/RC;
den=[1 1/RC];
H=tf(num,den);
bode(H);
t=[0:1:9000]'*1e-7;
figure
step(H);
figure
impulse(H,t);
