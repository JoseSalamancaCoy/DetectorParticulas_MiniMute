R1=51;
R2=51;
C=100e-9;
num=[R1*C 0];
den=[(R1+R2)*C 1];
H=tf(num,den);
bode(H);
